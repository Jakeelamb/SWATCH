"""SWATCH - A sleek, modern job monitoring tool for Slurm workload manager."""

__version__ = "0.1.0" 